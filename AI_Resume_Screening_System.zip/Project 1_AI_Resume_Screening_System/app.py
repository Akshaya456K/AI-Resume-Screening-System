import streamlit as st


# ============================================================
# PAGE CONFIGURATION
# ============================================================

st.set_page_config(
    page_title="ResumeAI - Resume Screening System",
    page_icon=None,
    layout="wide",
    initial_sidebar_state="expanded"
)


# ============================================================
# CUSTOM CSS
# ============================================================

st.markdown(
    """
    <style>

    /* --------------------------------------------------------
       GLOBAL
    -------------------------------------------------------- */

    .main {
        background-color: #f7f9fc;
    }

    #MainMenu {
        visibility: hidden;
    }

    footer {
        visibility: hidden;
    }

    /* --------------------------------------------------------
       HEADER
    -------------------------------------------------------- */

    .main-header {
        font-size: 32px;
        font-weight: 700;
        color: #111827;
        margin-bottom: 5px;
    }

    .sub-header {
        color: #6b7280;
        font-size: 15px;
        margin-bottom: 25px;
    }

    /* --------------------------------------------------------
       CARDS
    -------------------------------------------------------- */

    .card {
        background-color: white;
        padding: 22px;
        border-radius: 12px;
        border: 1px solid #e5e7eb;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        margin-bottom: 15px;
    }

    .card-title {
        font-size: 18px;
        font-weight: 600;
        color: #111827;
        margin-bottom: 8px;
    }

    /* --------------------------------------------------------
       METRICS
    -------------------------------------------------------- */

    .metric-value {
        font-size: 28px;
        font-weight: 700;
        color: #111827;
    }

    .metric-label {
        color: #6b7280;
        font-size: 13px;
        font-weight: 500;
    }

    /* --------------------------------------------------------
       CANDIDATE
    -------------------------------------------------------- */

    .candidate-name {
        font-size: 20px;
        font-weight: 650;
        color: #111827;
    }

    .candidate-role {
        color: #6b7280;
        font-size: 14px;
    }

    .score {
        font-size: 36px;
        font-weight: 700;
        color: #111827;
    }

    /* --------------------------------------------------------
       SIDEBAR
    -------------------------------------------------------- */

    section[data-testid="stSidebar"] {
        background-color: #111827;
    }

    section[data-testid="stSidebar"] * {
        color: white;
    }

    /* --------------------------------------------------------
       BUTTONS
    -------------------------------------------------------- */

    .stButton > button {
        border-radius: 8px;
        font-weight: 600;
    }

    /* --------------------------------------------------------
       TEXT AREA
    -------------------------------------------------------- */

    textarea {
        border-radius: 8px !important;
    }

    </style>
    """,
    unsafe_allow_html=True
)


# ============================================================
# SIDEBAR / NAVIGATION
# ============================================================

with st.sidebar:

    st.markdown(
        """
        <div style="
            font-size: 25px;
            font-weight: 700;
            margin-bottom: 5px;
        ">
            ResumeAI
        </div>
        """,
        unsafe_allow_html=True
    )

    st.caption("AI-Powered Recruitment Platform")

    st.divider()

    page = st.radio(
        "Navigation",
        [
            "Dashboard",
            "Screen Resumes",
            "Candidate Ranking",
            "Analytics"
        ]
    )

    st.divider()

    st.caption("System Status")

    st.success("AI Engine Ready")

    st.caption("NLP Matching • Ranking • Analysis")


# ============================================================
# DASHBOARD
# ============================================================

if page == "Dashboard":

    st.markdown(
        '<div class="main-header">AI Resume Screening System</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="sub-header">'
        'Intelligent candidate screening and ranking using '
        'Natural Language Processing and machine learning.'
        '</div>',
        unsafe_allow_html=True
    )

    # --------------------------------------------------------
    # METRICS
    # --------------------------------------------------------

    col1, col2, col3, col4 = st.columns(4)

    with col1:

        st.markdown(
            """
            <div class="card">
                <div class="metric-label">TOTAL JOBS</div>
                <div class="metric-value">50</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col2:

        st.markdown(
            """
            <div class="card">
                <div class="metric-label">TOTAL CANDIDATES</div>
                <div class="metric-value">200</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col3:

        st.markdown(
            """
            <div class="card">
                <div class="metric-label">TOTAL APPLICATIONS</div>
                <div class="metric-value">1,000</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with col4:

        st.markdown(
            """
            <div class="card">
                <div class="metric-label">AI ENGINE</div>
                <div class="metric-value">Ready</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # --------------------------------------------------------
    # QUICK ACTIONS
    # --------------------------------------------------------

    st.subheader("Quick Actions")

    col1, col2 = st.columns(2)

    with col1:

        st.markdown(
            """
            <div class="card">

                <div class="card-title">
                    Screen New Resumes
                </div>

                <p>
                    Upload a job description and multiple resumes
                    to evaluate candidate relevance.
                </p>

            </div>
            """,
            unsafe_allow_html=True
        )

        if st.button(
            "Start Screening",
            use_container_width=True
        ):
            st.info(
                "Select 'Screen Resumes' from the navigation menu."
            )

    with col2:

        st.markdown(
            """
            <div class="card">

                <div class="card-title">
                    Candidate Rankings
                </div>

                <p>
                    Review candidates according to their
                    calculated relevance score.
                </p>

            </div>
            """,
            unsafe_allow_html=True
        )

        if st.button(
            "View Rankings",
            use_container_width=True
        ):
            st.info(
                "Select 'Candidate Ranking' from the navigation menu."
            )


# ============================================================
# SCREEN RESUMES
# ============================================================

elif page == "Screen Resumes":

    st.markdown(
        '<div class="main-header">Screen Resumes</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="sub-header">'
        'Provide a job description and upload candidate resumes '
        'for AI-based screening.'
        '</div>',
        unsafe_allow_html=True
    )

    # --------------------------------------------------------
    # JOB DESCRIPTION
    # --------------------------------------------------------

    st.markdown(
        '<div class="card">',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="card-title">Job Description</div>',
        unsafe_allow_html=True
    )

    job_description = st.text_area(
        "Job Requirements",
        height=220,
        placeholder=(
            "Enter the job description here.\n\n"
            "Example:\n"
            "We are looking for a Data Scientist with experience "
            "in Python, SQL, Machine Learning and Statistics."
        ),
        label_visibility="collapsed"
    )

    st.markdown(
        "</div>",
        unsafe_allow_html=True
    )

    # --------------------------------------------------------
    # RESUME UPLOAD
    # --------------------------------------------------------

    st.markdown(
        '<div class="card">',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="card-title">Upload Candidate Resumes</div>',
        unsafe_allow_html=True
    )

    uploaded_resumes = st.file_uploader(
        "Upload resumes",
        type=["pdf", "docx", "txt"],
        accept_multiple_files=True,
        label_visibility="collapsed"
    )

    st.markdown(
        "</div>",
        unsafe_allow_html=True
    )

    # --------------------------------------------------------
    # SCREENING BUTTON
    # --------------------------------------------------------

    if st.button(
        "Start AI Screening",
        type="primary",
        use_container_width=True
    ):

        if not job_description.strip():

            st.warning(
                "Please enter a job description before starting screening."
            )

        elif not uploaded_resumes:

            st.warning(
                "Please upload at least one resume."
            )

        else:

            st.success(
                f"{len(uploaded_resumes)} resume(s) uploaded successfully."
            )

            st.info(
                "The AI screening engine will be connected to this "
                "interface in the next stage."
            )


# ============================================================
# CANDIDATE RANKING
# ============================================================

elif page == "Candidate Ranking":

    st.markdown(
        '<div class="main-header">Candidate Ranking</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="sub-header">'
        'Candidates will be ranked according to their AI-generated '
        'relevance score.'
        '</div>',
        unsafe_allow_html=True
    )

    # --------------------------------------------------------
    # NO RESULTS YET
    # --------------------------------------------------------

    st.info(
        "No screening results are available yet. "
        "Upload resumes and run AI Screening to generate "
        "candidate rankings."
    )


# ============================================================
# ANALYTICS
# ============================================================

elif page == "Analytics":

    st.markdown(
        '<div class="main-header">Screening Analytics</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="sub-header">'
        'Overview of candidate screening performance and '
        'matching components.'
        '</div>',
        unsafe_allow_html=True
    )

    # --------------------------------------------------------
    # METRICS
    # --------------------------------------------------------

    col1, col2, col3 = st.columns(3)

    with col1:

        st.metric(
            "Average Match Score",
            "—"
        )

    with col2:

        st.metric(
            "Highly Relevant Candidates",
            "—"
        )

    with col3:

        st.metric(
            "Candidates Screened",
            "—"
        )

    st.divider()

    # --------------------------------------------------------
    # MATCHING COMPONENTS
    # --------------------------------------------------------

    st.subheader("Matching Components")

    st.info(
        "Analytics will be displayed here after the real "
        "screening engine is connected."
    )

#run this code by running this in the terminal "python -m streamlit run app.py"