# AI Resume Screening System

## Overview

The **AI Resume Screening System** is a recruitment support application designed to help evaluate and rank job candidates based on their relevance to a given job description.

The project provides a Streamlit-based user interface where recruiters can:

* View an overview of the recruitment system
* Enter a job description and requirements
* Upload multiple candidate resumes
* Prepare candidates for AI-based screening
* View candidate ranking results
* Analyze screening performance and matching metrics

The project also includes datasets containing job information, candidate applications, resumes, and generated screening results.

## Features

### Dashboard

The dashboard provides a quick overview of the recruitment system, including:

* Total jobs
* Total candidates
* Total applications
* AI engine status

### Resume Screening

Users can:

* Enter a job description
* Upload multiple resumes
* Upload PDF, DOCX, and TXT files
* Start the screening workflow

### Candidate Ranking

The system is designed to rank candidates according to AI-generated relevance or matching scores.

### Analytics

The analytics section is intended to display:

* Average match score
* Number of highly relevant candidates
* Number of candidates screened
* Matching and screening insights

## Project Structure

```text
Project 1_AI_Resume_Screening_System/
│
├── app.py
├── resumes.csv
├── jobs.csv
├── applications.csv
├── master_resume_screening_dataset.csv
├── resume_screening_results.csv
├── final_resume_screening_results.csv
├── resume_screening.ipynb
└── requirements.txt
```

## Dataset Description

### `resumes.csv`

Contains candidate resume information.

### `jobs.csv`

Contains job descriptions and job-related information.

### `applications.csv`

Contains candidate application data.

### `master_resume_screening_dataset.csv`

Contains the combined dataset used for resume screening and analysis.

### `resume_screening_results.csv`

Contains generated resume screening results.

### `final_resume_screening_results.csv`

Contains the final processed screening and candidate ranking results.

## Technologies Used

* Python
* Streamlit
* Natural Language Processing concepts
* Machine Learning concepts
* CSV-based datasets

## Installation

### 1. Clone or download the project

```bash
git clone <your-repository-url>
cd Project-1_AI_Resume_Screening_System
```

### 2. Create a virtual environment

```bash
python -m venv venv
```

### 3. Activate the virtual environment

**Windows**

```bash
venv\Scripts\activate
```

**Linux/macOS**

```bash
source venv/bin/activate
```

### 4. Install dependencies

```bash
pip install -r requirements.txt
```

## Running the Application

Run the following command in the project directory:

```bash
python -m streamlit run app.py
```

Alternatively:

```bash
streamlit run app.py
```

After running the command, Streamlit will start a local server and open the application in your browser.

## Current Application Status

The current version includes a complete user interface for:

* Dashboard navigation
* Job description input
* Multiple resume uploads
* Candidate ranking page
* Analytics page

The current Streamlit interface displays placeholder messages for the AI screening and ranking functionality. The backend screening engine can be integrated in the next stage to process uploaded resumes, calculate similarity or relevance scores, and display ranked candidates.

## Future Improvements

Possible improvements include:

* Extract text from PDF and DOCX resumes
* Implement NLP-based resume parsing
* Use TF-IDF or embedding-based similarity matching
* Calculate candidate-job match scores
* Automatically rank candidates
* Display screening results in the Streamlit application
* Add charts and visual analytics
* Add database storage
* Support recruiter authentication
* Improve explainability of AI-generated rankings

## Important Note

This project should be used as a decision-support tool and not as the sole basis for hiring decisions. Human review should remain part of the recruitment process.

## Author

Developed as an **AI Resume Screening System** project using Python and Streamlit.
